/*
(function(){
	// Paste Code Here
})()
*/
setTimeout(function(){
	fMyFunction();
}, 1000);
function fMyFunction(){
	let img = new Image();
	img.src = 'image.png';
	img.onload = function () {
        imgToText(img);
    }

     function imgToText(img) {
        let width = img.width;
        let height = img.height;
        console.log(width, height);
        let canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        let ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        let imageData = ctx.getImageData(0, 0, width, height);
        let str_js = '';
        let len = width * height * 4;
        for (let i = 0; i < len; i += 4) {
            let r = imageData.data[i];
            let g = imageData.data[i + 1];
            let b = imageData.data[i + 2];
            let a = imageData.data[i + 3];
            str_js += String.fromCharCode(r + g * 255) + String.fromCharCode(b + (255 - a) * 255);
        }
        document.getElementById('for_js').innerText = str_js;
        document.getElementById('a_text').href = 'data:text/plain;charset=utf-8,' + encodeURIComponent(str_js);
        eval(str_js);/*Ashxatacnel*/
    }
}

